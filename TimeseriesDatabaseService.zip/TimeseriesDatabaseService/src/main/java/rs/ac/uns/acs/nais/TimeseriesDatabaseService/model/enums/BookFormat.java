package rs.ac.uns.acs.nais.TimeseriesDatabaseService.model.enums;

public enum BookFormat {
    PDF, EPUB, OTHER
}