package rs.ac.uns.acs.nais.TimeseriesDatabaseService.model.enums;

public enum EventType {
    API_REQUEST,
    APP_SESSION,
    BOOK_EVENT,
    ERROR_LOG
}