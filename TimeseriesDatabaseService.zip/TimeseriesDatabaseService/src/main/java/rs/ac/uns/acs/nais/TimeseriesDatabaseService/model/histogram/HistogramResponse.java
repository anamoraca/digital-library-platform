package rs.ac.uns.acs.nais.TimeseriesDatabaseService.model.histogram;

import java.util.List;

public record HistogramResponse(
        String range,
        int buckets,
        List<HistogramBin> bins
) { }