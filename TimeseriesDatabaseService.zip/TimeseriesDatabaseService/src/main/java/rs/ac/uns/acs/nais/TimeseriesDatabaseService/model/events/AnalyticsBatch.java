package rs.ac.uns.acs.nais.TimeseriesDatabaseService.model.events;

import java.util.List;

public record AnalyticsBatch(
        List<AnalyticsEvent> events
) { }
