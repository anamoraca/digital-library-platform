package rs.ac.uns.acs.nais.TimeseriesDatabaseService.model.enums;

public enum BookEventType {
    OPENED, CLOSED, PROGRESS
}