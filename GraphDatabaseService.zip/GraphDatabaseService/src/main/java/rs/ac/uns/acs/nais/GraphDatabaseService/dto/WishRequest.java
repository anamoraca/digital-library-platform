package rs.ac.uns.acs.nais.GraphDatabaseService.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor @AllArgsConstructor @Builder
public class WishRequest {
    private String note;
}
