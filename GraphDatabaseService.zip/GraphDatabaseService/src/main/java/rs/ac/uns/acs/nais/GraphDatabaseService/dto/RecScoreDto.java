package rs.ac.uns.acs.nais.GraphDatabaseService.dto;

public record RecScoreDto(String bookId, String title, Double score) {}
