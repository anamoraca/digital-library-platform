package rs.ac.uns.acs.nais.GraphDatabaseService.dto;

public record BookTrendDto(Integer year, String lang, Long reads) {}
