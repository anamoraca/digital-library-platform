package rs.ac.uns.acs.nais.GraphDatabaseService.dto;

public record TopGenreDto(String genreId, String genreName, Long cnt) {}
