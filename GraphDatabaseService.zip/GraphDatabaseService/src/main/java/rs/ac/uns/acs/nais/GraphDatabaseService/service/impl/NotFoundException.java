package rs.ac.uns.acs.nais.GraphDatabaseService.service.impl;

public class NotFoundException extends RuntimeException {
    public NotFoundException(String msg) { super(msg); }
}

